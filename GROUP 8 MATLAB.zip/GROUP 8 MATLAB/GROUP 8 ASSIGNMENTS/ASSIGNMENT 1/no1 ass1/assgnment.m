% MATLAB Script: Visualize parameters, patterns, and trends from ALL_TABLES.xlsx
clc; clear; close all;

% === STEP 1: Load all sheets into a master table ===
filename = 'ALL_TABLES.xlsx';
[~, sheets] = xlsfinfo(filename);
allData = table();

for i = 1:numel(sheets)
    T = readtable(filename, 'Sheet', sheets{i});
    allData = [allData; T]; %#ok<AGROW>
end

% === STEP 2: Create output folder for images ===
outputFolder = 'Plots';
if ~exist(outputFolder, 'dir')
    mkdir(outputFolder);
end

% === STEP 3: Visualization 1 - Price trend per year ===
figure;
boxplot(allData.Price_USD, allData.Year);
xlabel('Year');
ylabel('Price (USD)');
title('Vehicle Price Distribution per Year');
grid on;
saveas(gcf, fullfile(outputFolder, 'Price_Trend_Per_Year.png'));

% === STEP 4: Visualization 2 - Sales Volume trend ===
figure;
avgSales = groupsummary(allData, 'Year', 'mean','Sales_Volume');
plot(avgSales.Year, avgSales.mean_Sales_Volume, '-o', 'LineWidth', 2);
xlabel('Year');
ylabel('Average Sales Volume');
title('Average Sales Volume per Year');
grid on;
saveas(gcf, fullfile(outputFolder, 'Sales_Volume_Trend.png'));

% === STEP 5: Visualization 3 - Price vs Mileage relationship ===
figure;
scatter(allData.Mileage_KM, allData.Price_USD, 25, 'filled');
xlabel('Mileage (KM)');
ylabel('Price (USD)');
title('Relationship between Mileage and Price');
grid on;
saveas(gcf, fullfile(outputFolder, 'Price_vs_Mileage.png'));

%% === STEP 6: Visualization 4 - Fuel Type distribution ===
figure;
fuelCounts = groupsummary(allData,'Fuel_Type','numel') ;
bar(categorical(fuelCounts.Fuel_Type), fuelCounts.GroupCount);
xlabel('Fuel Type');
ylabel('Number of Vehicles');
title('Distribution by Fuel Type');
grid on;
saveas(gcf, fullfile(outputFolder, 'Fuel_Type_Distribution.png'));

%% === STEP 7: Visualization 5 - Sales Classification vs Region ===
figure;
regionCounts = groupsummary(allData, {'Region','Sales_Classification'}, 'numel');
g = gramm('x', regionCounts.Region, ...
          'y', regionCounts.GroupCount, ...
          'color', regionCounts.Sales_Classification);
g.geom_bar('stacked');
g.set_title('Sales Classification per Region');
g.set_names('x','Region','y','Count','color','Sales Class');
g.set_text_options('rotation',45);
g.draw();
saveas(gcf, fullfile(outputFolder, 'Sales_Classification_Region.png'));

disp('All plots generated and saved successfully.');

